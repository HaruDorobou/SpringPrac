package com.practice.Hsg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HsgApplication {

	public static void main(String[] args) {
		SpringApplication.run(HsgApplication.class, args);
	}

}

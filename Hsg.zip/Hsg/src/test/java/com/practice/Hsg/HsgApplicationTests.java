package com.practice.Hsg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HsgApplicationTests {

	@Test
	void contextLoads() {
	}

}
